<?php
set_time_limit(0);
error_reporting(0);
cli_set_process_title('SMTP Api V.2 | ImamBlack');
require 'PHPMailer/class.smtp.php';
require 'PHPMailer/class.phpmailer.php';
class SMTPApi {
	var $h0st = "smtp.gmail.com";
	var $custom	= "id-[RAND]";
	var $sendlog = "logsrelay";
	var $encoding = "yes";
	
	public function __construct() {
		$this->SendID = "ybh_".substr(md5(rand(11111,99999)),0,7);
		return $this;
	}
	
	private function CreteLogSend($dir) {
		if(!is_dir($dir)) {
			@mkdir($dir);
		}
	}

	private function RandLine($fileName) {
		$f_contents = file($fileName);
		$line = $f_contents[array_rand($f_contents)];
		return $line;
	}
	
	private function RandChar($panjang) {
		$pstring = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; 
		$plen = strlen($pstring); 
		for ($i = 1; $i <= $panjang; $i++) {
			$start = rand(0,$plen); 
			$unik .= substr($pstring, $start, 1); 
		}	   
		return $unik;
	}

	private function DeleteEmail($no, $total, $email, $file) {
		if($no == $total) {
			@unlink($file);
			echo "[".date("H:i:s")." $no/$total] File ".$file." has been DELETED\n";
		} else {
			$get = file_get_contents($file);
			$delete = str_replace($email."\r\n", "", $get);
			if($delete) {
				$save = fopen($file, "w");
				fwrite($save, $delete);
			} else {
				$delete2 = str_replace($email."\n", "", $get);
				if($delete2) {
					$save = fopen($file, "w");
					fwrite($save, $delete2);
				}
			}
		}
	}
	
	public function Send($no, $total, $email, $letter_file, $resurce_file) {
		$this->CreteLogSend($this->sendlog);
		$rand = rand(1111,9999);
		$loadapi = $this->RandLine("conf/smtp.txt");
		$config = explode("|", $loadapi);
		$password = str_replace(array("\n", "\r"), "", $config[1]);
		$username = str_replace(array("\n", "\r"), "", $config[0]);
		$browser  = $this->RandLine("conf/browser.txt");
		$os = $this->RandLine("conf/os.txt");
		$date = date('d F Y, h:i A');
		$email = preg_replace("/\r\n|\r|\n/",'',$email);
		$scamlink = $this->RandLine("conf/scam_link.txt");
		$scamlink = str_replace(array("\n", "\r"), "", $scamlink);
		$scamlink = str_replace("XXX", $this->RandChar(3), $scamlink);
		$scamlink = str_replace("YYY", $this->RandChar(3), $scamlink);
		$scamlink = str_replace("ZZZ", $this->RandChar(3), $scamlink);
		$letter = str_replace(array("\n", "\r"), "", file_get_contents($letter_file));
		$letter = str_replace("##os##", $os, $letter);
		$letter = str_replace("##browser##", $browser, $letter);
		$letter = str_replace("##date##", $date, $letter);
		$letter = str_replace("##url##", $scamlink, $letter);
		$letter = str_replace("##email##", "".$email."", $letter);
		$subject = $this->RandLine("conf/subject.txt");
		$subject = str_replace("##os##", $os, $subject);
		$subject = str_replace("##browser##", $browser, $subject);
		$subject = str_replace(array("\n", "\r"), "", $subject);
		$fromn = $this->RandLine("conf/from_name.txt");
		$fromn = str_replace(array("\n", "\r"), "", $fromn);
		if ($this->encoding == "yes") {
			$subject = preg_replace('/([^a-z ])/ie', 'sprintf("=%02x",ord(StripSlashes("\\1")))', $subject);
			$subject = str_replace(' ', '=20', $subject);
			$subject = "=?utf-8?Q?$subject?=";
			$fromn = preg_replace('/([^a-z ])/ie', 'sprintf("=%02x",ord(StripSlashes("\\1")))', $fromn);
			$fromn = str_replace(' ', '=20', $fromn);
			$fromn = "=?utf-8?Q?$fromn?=";
		}
		$frome = $this->RandLine("conf/from_email.txt");
		$frome = str_replace(array("\n", "\r"), "", $frome);
		$frome = str_replace("##rand##", $rand, $frome);
		$email = str_replace(array("\n", "\r"), "", $email);
		$custom = str_replace("[RAND]", $rand, $this->custom);
		$mail = New PHPMailer();
		$mail->ClearAddresses();
		$mail->SingleTo = true;
        $mail->isSMTP();
		$mail->SMTPKeepAlive = true;
		$mail->IsHTML(true);
		$mail->Host = $this->h0st;
		$mail->SMTPDebug  = 0;
		$mail->Port = 587;
		$mail->SMTPSecure = "tls";
		$mail->SMTPAuth = true;
		$mail->Username = $username;
		$mail->Password = $password;
		$mail->CharSet = "UTF-8";
		$mail->setFrom($frome, $fromn, FALSE);
		$mail->addReplyTo($username, $fromn);
		$mail->addAddress($email);
		$mail->Subject = $subject;
		#$mail->addCustomHeader('From', "".$fromn." <".$frome.">");
		$mail->addCustomHeader('X-https', $custom);
		$mail->MsgHTML($letter);
		$mail->send();
		if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
			$user = explode("@", $username);
			if (empty($mail->ErrorInfo) or stristr($mail->ErrorInfo,"Invalid address:")) {
				if ($this->encoding == "yes") {
					echo "[".date("H:i:s")." $no/$total] ".$user[0]." > ".$email." -> Message Sent !! ok\n";
				} else {
					echo "[".date("H:i:s")." $no/$total] ".$user[0]." > ".$email." -> Message Sent !! ok | ".$subject."\n";
				}
				$save = fopen($this->sendlog."/".$this->SendID."_SUCCESS.txt", "a");
				fwrite($save, $email."\n");
			} else {
				echo "[".date("H:i:s")." $no/$total] ERROR ".$mail->ErrorInfo." ".$user[0]." > ".$email."\n";
				$save = fopen($this->sendlog."/".$this->SendID."_ERROR.txt", "a");
				fwrite($save, "ERROR ".$mail->ErrorInfo."|".$email."\n");
			}
		} else {
			echo "[".date("H:i:s")." $no/$total] INVALID EMAIL > ".$email."\n";
			$save = fopen($this->sendlog."/".$this->SendID."_INVALID.txt", "a");
			fwrite($save, $email."\n");
		}
		$mail->SmtpClose();
		$void = PHPMailer::smtpClose();
		if(!empty($resurce_file)) {
			$this->DeleteEmail($no, $total, $email, $resurce_file);
		}
	}
	
	public function ShowSendHeader() {		
		$getapi	  = file_get_contents("conf/from_name.txt");
		$api	  = explode("\n",$getapi);
		$totalapi = count($api);
		$getsbj	  = file_get_contents("conf/subject.txt");
		$subject  = explode("\n",$getsbj);
		$totalsbj = count($subject);
		$getdes	  = file_get_contents("conf/from_email.txt");
		$descript = explode("\n",$getdes);
		$totaldes = count($descript);
		echo "\n--------------------------------------------------------------------------\n";
		echo "[+] SMTP Api V.2 | ImamBlack\n";
		echo "--------------------------------------------------------------------------\n";
		echo "[+] Send ID : ".$this->SendID."\n";
		echo "[+] Log Directory : ".$this->sendlog."\n";
		echo "[+] Start Time : ".date("d-m-Y H:i:s")."\n";
		echo "[+] Total From Name : ".$totalapi."\n";
		echo "[+] Total From Email : ".$totaldes."\n";
		echo "[+] Total Subject : ".$totalsbj."\n";
	}
	
	public function ShowSendFooter() {		
		$geterror = file_get_contents($this->sendlog."/".$this->SendID."_ERROR.txt");
		$error    = explode("\n",$geterror);
		$totalerr = count($error)-1;
		$getinv   = file_get_contents($this->sendlog."/".$this->SendID."_INVALID.txt");
		$invalid  = explode("\n",$getinv);
		$totalinv = count($invalid)-1;
		$getsuc   = file_get_contents($this->sendlog."/".$this->SendID."_SUCCESS.txt");
		$success  = explode("\n",$getsuc);
		$totalsuc = count($success)-1;
		echo "--------------------------------------------------------------------------\n";
		echo "[+] End Time : ".date("d-m-Y H:i:s")."\n";
		echo "[+] Total Error : ".$totalerr."\n";
		echo "[+] Total Invalid : ".$totalinv."\n";
		echo "[+] Total Successfully : ".$totalsuc."\n";
		echo "--------------------------------------------------------------------------\n";
	}
	
}

$Logo = "  
______ _________      _____    _________    _____________       _____    _____________  ____
\    | \        \    /  _  \   \        \   \  ___  \    |     /     \   \       \    |/   /
 |   | /  |  |   \  /  /_\  \  /  |  |   \  /       /|   |__  /  /_\  \  / ______/|       /
 |   |/   |  |    \/    |    \/   |  |    \/   ___  \|      \/    |    \/        \|       \ 
 |_  /\___|__|__  /\____|__  /\___|__|__  /\______  /\____  /\____|__  /\______  /|___|_  /
   \/           \/         \/           \/        \/      \/         \/        \/       \/  
   
                                           (C) ".date("Y")." DARKPLOIT SOCIETY & YOGYAKARTA BLACK HAT
";
$mail = new SMTPApi();
if(isset($argv[1]) && isset($argv[2]) && isset($argv[3])) {
	$get	  = file_get_contents($argv[1]) or die("\nStupidly ".date("H:i:s")." - File ".$argv[1]." not FOUNDED ...!\n");
	$emails	  = explode("\n",$get);
	$total	  = count($emails);
	$no	      = 1;
	$mail->ShowSendHeader();
	echo "[+] Total Email : ".$total."\n";
	if($argv[2] == "Y" or $argv[2] == "y") {
		echo "[+] Remove Sended Email : YES\n";
	} else {
		echo "[+] Remove Sended Email : NO\n";
	}
	if(!empty($argv[4])) {
		echo "[+] Send Delay : ".$argv[4]." second\n";
	} else {
		echo "[+] Send Delay : 1 second\n";
	}
	echo "--------------------------------------------------------------------------\n";
	foreach($emails as $email){
		if(!empty($argv[4])) {
			@sleep($argv[4]);
		}
		if($argv[3] == "Y" or $argv[3] == "y") {
			$mail->Send($no, $total, $email, $argv[2], $argv[1]);
		} else {
			$mail->Send($no, $total, $email, $argv[2]);
		}
		$no++;
	}
	$mail->ShowSendFooter();
} else {
	echo $Logo."\n";
    echo "[+] Author  : ImamBlack\n";
    echo "[+] Contact : imamblack@sigaint.org\n";
    echo "[+] Usage   : php ".basename($_SERVER["SCRIPT_FILENAME"], '.php').".php <email_list.txt> <letter.html> <delete sended email Y/N> <delay in second if empty will 1 second>\n";
	echo "[+] Example : - php ".basename($_SERVER["SCRIPT_FILENAME"], '.php').".php list.txt letter.html Y\n";
	echo "              - php ".basename($_SERVER["SCRIPT_FILENAME"], '.php').".php list.txt letter.html N\n";
	echo "              - php ".basename($_SERVER["SCRIPT_FILENAME"], '.php').".php list.txt letter.html Y 20\n";
}
?>
